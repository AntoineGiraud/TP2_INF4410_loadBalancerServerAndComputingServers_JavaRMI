Vous devez obligatoirement utiliser la classe Operations fournie
dans cette archive pour obtenir les resultats des operations
mathematiques.

Vous pouvez utiliser les fichiers donnees-*.txt pour tester votre
systeme reparti. La valeur numerique presente dans le nom du
fichier indique le resultat attendu.
